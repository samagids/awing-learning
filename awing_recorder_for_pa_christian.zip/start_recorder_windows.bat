@echo off
REM ==============================================================
REM  Awing Voice Recorder - Launcher for Pa Christian Alomofor
REM ==============================================================
REM  This script starts a tiny web server on your own computer
REM  so the microphone works in any browser (Chrome / Edge / Firefox).
REM  It needs Python installed. If Python is not installed, please
REM  follow the universal method in READ_ME_FIRST.txt (use Firefox).
REM ==============================================================
setlocal

cd /d "%~dp0"

echo.
echo  Awing Voice Recording
echo  =====================
echo.
echo  Starting the recorder on your own computer...
echo  When the browser opens, you can record. The browser will
echo  ask for microphone permission - click Allow.
echo.
echo  TO STOP: close this black window when you are done.
echo.

REM Check for Python
python --version >nul 2>&1
if errorlevel 1 (
  py --version >nul 2>&1
  if errorlevel 1 (
    echo.
    echo  ERROR: Python is not installed on this computer.
    echo.
    echo  Please follow the universal method in READ_ME_FIRST.txt:
    echo    1. Download Firefox from https://www.mozilla.org/firefox
    echo    2. Open native_speaker_recorder.html in Firefox
    echo    3. Click "Allow" when it asks for the microphone
    echo.
    pause
    exit /b 1
  )
  set "PY=py"
) else (
  set "PY=python"
)

start "" "http://localhost:8765/native_speaker_recorder.html"
%PY% -m http.server 8765
