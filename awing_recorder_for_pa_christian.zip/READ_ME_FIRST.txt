AWING VOICE RECORDING — FOR PA CHRISTIAN ALOMOFOR
====================================================

Pa Christian,

Thank you for agreeing to help bring your Awing dictionary to life
by lending your voice to the children's learning app.

This folder contains:

  1. native_speaker_recorder.html  - The recording page (fully offline)
  2. start_recorder_windows.bat    - A one-click launcher (Windows)
  3. READ_ME_FIRST.txt             - This file

The recorder works completely offline. No internet connection is
needed after you extract this ZIP.

----------------------------------------------------------------------
HOW TO START — EASIEST METHOD (WINDOWS)
----------------------------------------------------------------------

If you have Python installed on your Windows computer:

  - Double-click "start_recorder_windows.bat"
  - Your default browser will open the recorder page automatically
  - The microphone will work because the page is served from your
    own computer

----------------------------------------------------------------------
HOW TO START — UNIVERSAL METHOD (ALL COMPUTERS)
----------------------------------------------------------------------

If you don't have Python, or if the .bat file does not work:

  1. Download Firefox (free): https://www.mozilla.org/firefox
  2. Right-click "native_speaker_recorder.html"
     -> Open with -> Firefox
  3. The first time you click a recording button, Firefox will ask
     for permission to use the microphone — click "Allow".

Chrome and Edge do NOT allow microphones on local files. Firefox does.

----------------------------------------------------------------------
HOW TO RECORD
----------------------------------------------------------------------

  1. Your name "Pa Christian Alomofor" is already filled in at the top.
     You don't need to type anything.

  2. The page shows Awing words, phrases, and sentences. Use the
     filter buttons to focus on what you'd like to record first.
     The "Beginner words" filter is a good place to start — those
     are the most common everyday words.

  3. Click the green Record button next to a word.
     Speak the word clearly and naturally, the way you would say it
     to a young child.
     Click Stop when done.

  4. The recording is saved to your Downloads folder automatically.
     Each filename is like:
        native_pa_christian_alomofor__apo.webm

  5. Click the Play button to listen. If you want to record again,
     click Re-record.

  6. Your progress is saved automatically. You can close the page
     and come back later. (Use the same browser on the same computer.)

----------------------------------------------------------------------
HOW TO SEND THE RECORDINGS BACK
----------------------------------------------------------------------

When you have finished (or whenever you want to send what you have):

  1. Click the green "Download all as ZIP" button at the bottom of
     the page.

  2. Your computer will create one ZIP file named:
        awing_recordings_pa_christian_alomofor.zip

  3. Email the ZIP file to:
        samagids@gmail.com

  4. Or, share it through WhatsApp / Google Drive / any way you like.

----------------------------------------------------------------------
TIPS FOR THE BEST RESULTS
----------------------------------------------------------------------

  - Quiet room (no fan, no TV in the background)
  - Sit about 6 inches (15 cm) from the microphone
  - Speak at a normal pace — not too fast, not too slow
  - One word per recording — clear and natural
  - For sentences and phrases: read them as you would in conversation
  - You do NOT have to record everything. Even 100 words from you
    is a tremendous gift to the project.

----------------------------------------------------------------------
NEED HELP?
----------------------------------------------------------------------

If anything is unclear or not working, please contact:

  Dr. Guidion Sama
  Email: samagids@gmail.com

Thank you, Pa Christian. Your voice will teach Awing to
generations of children.

— The Awing AI Learning team
